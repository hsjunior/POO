import java.util.Scanner;

public class ContaCorrente extends Conta {
    private double limite;

    public ContaCorrente(Gerente ger) {
        super(ger);
        Scanner s = new Scanner(System.in);
        this.setLimite(s.nextDouble());
    }

    public ContaCorrente(String numero, Pessoa titular, Gerente ger, int dia, int mes, int ano, double limite) {
        super(numero, titular, ger, dia, mes, ano);
        this.setLimite(limite);
    }

    public void alterarLimite(String senha, double limite) {
        if (this.getGer().validarAcesso(senha)) {
            this.setLimite(limite);
            System.out.println("Senha alterada com sucesso.");
        }
        else {
            System.out.println("ERRO: Senha invalida.");
        }
    }

    public void alterarLimite() {
        Scanner s = new Scanner(System.in);

        System.out.println("Digite a senha: ");
        String senha = s.nextLine();

        System.out.println("Digite o novo limite: ");
        double limite = s.nextDouble();

        this.alterarLimite(senha, limite);
    }

    protected double disponivel() {
        return this.getSaldo() + this.getLimite();
    }

    public void extrato() {
        System.out.println("*** EXTRATO DE CONTA CORRENTE ***");
        super.extrato();
    }

    public void chequeEspecial(double juro) {
        if (this.getSaldo() < 0) {
            this.setSaldo(this.getSaldo() + (this.getSaldo() * juro / 100));
        }
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }
}
