import java.util.Scanner;

public class Pessoa {
    protected String nome;
    protected Data dtNasc;
    protected char sexo;
    protected String cpf;

    public Pessoa() {
        Scanner s = new Scanner(System.in);

        System.out.println("Digite o nome: ");
        this.setNome(s.nextLine());

        System.out.println("Digite o cpf: ");
        this.setNome(s.nextLine());

        System.out.println("Data de nascimento: ");
        this.setDtNasc(new Data());

        System.out.println("Digite o sexo (M/F): ");
        this.setSexo(s.next().charAt(0));
    }

    public Pessoa(String nome, int dia, int mes, int ano, char sexo, String cpf) {
        this.setNome(nome);
        this.setDtNasc(new Data(dia, mes, ano));
        this.setSexo(sexo);
        this.setCpf(cpf);
    }

    public int idade(Data dataAtual) {
        int x = dataAtual.getAno() - this.getDtNasc().getAno();

        if (dataAtual.getMes() < this.getDtNasc().getMes()) return x - 1;
        if (dataAtual.getMes() > this.getDtNasc().getMes()) return x;

        if (dataAtual.getDia() < this.getDtNasc().getDia()) return x - 1;
        return x;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Data getDtNasc() {
        return dtNasc;
    }

    public void setDtNasc(Data dtNasc) {
        this.dtNasc = dtNasc;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
}
