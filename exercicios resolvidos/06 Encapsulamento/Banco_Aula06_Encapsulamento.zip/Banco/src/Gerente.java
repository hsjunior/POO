import java.util.Scanner;

public class Gerente extends Pessoa {
    private String matricula;
    private String senha;

    public Gerente() {
        super();

        Scanner s = new Scanner(System.in);

        System.out.println("Matricula: ");
        this.setMatricula(s.nextLine());

        System.out.println("Senha: ");
        this.senha = s.nextLine();
    }

    public Gerente(String nome, int dia, int mes, int ano, char sexo, String cpf, String matricula, String senha) {
        super(nome, dia, mes, ano, sexo, cpf);
        this.setMatricula(matricula);
        this.senha = senha;
    }

    public boolean validarAcesso(String senha) {
        return (this.senha.equals(senha));
    }

    public boolean validarAcesso() {
        Scanner s = new Scanner(System.in);
        String senha = s.nextLine();
        return (this.validarAcesso(senha));
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
}
