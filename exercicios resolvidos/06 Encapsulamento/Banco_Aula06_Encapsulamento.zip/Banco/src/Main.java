import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        System.out.println("Criando dois gerentes:");
        Gerente g1 = new Gerente();
        Gerente g2 = new Gerente();

        System.out.println("Criando duas contas correntes:");
        ContaCorrente c1 = new ContaCorrente(g1);
        ContaCorrente c2 = new ContaCorrente(g2);

        System.out.println("Criando duas poupanças:");
        Poupanca p1 = new Poupanca(g1);
        Poupanca p2 = new Poupanca(g2);

        c1.sacar(30);
        p1.sacar(100);
        p1.depositar(50);
        c1.transferir(200, p1);
        c2.transferir(50, p2);

        c1.extrato();
        c2.extrato();
        p1.extrato();
        p2.extrato();
    }
}