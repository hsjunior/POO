import java.util.ArrayList;

public class Empresa {
    ArrayList<Funcionario> funcionarios;
    ArrayList<Gerente> gerentes;

    public Empresa() {
        this.funcionarios = new ArrayList<>();
        this.gerentes = new ArrayList<>();
    }

    public boolean listarFuncionarios() {
        if (funcionarios.isEmpty()) {
            System.out.println("Empresa sem funcionarios cadastrados.");
            return false;
        }
        else {
            for (Funcionario f : funcionarios) {
                f.listarDados();
            }
            return true;
        }
    }

    public boolean listarGerentes() {
        if (gerentes.isEmpty()) {
            System.out.println("Empresa sem gerentes cadastrados.");
            return false;
        }
        else {
            for (Gerente g : gerentes) {
                g.listarDados();
            }
            return true;
        }
    }

    public void folhaPagamento() {
        if (gerentes.isEmpty() && funcionarios.isEmpty()) {
            System.out.println("Empresa sem funcionarios ou gerentes cadastrados.");
        }
        else {
            double total = 0;

            for (Gerente g : gerentes) {
                g.listarDados();
                System.out.println("Custo da equipe: R$ " + g.custoEquipe());
                total += g.getSalario();
            }

            for (Funcionario f : funcionarios) {
                f.listarDados();
                total += f.getSalario();
            }

            System.out.println("Custo total da empresa: R$ " + total);
        }
    }

    public void inserirFuncionario(Funcionario f) {
        this.funcionarios.add(f);
    }

    public void inserirGerente(Gerente g) {
        this.gerentes.add(g);
    }

    public Funcionario funcionarioMaisAntigo() {
        Funcionario f = null;

        for (Funcionario func : funcionarios) {
            if (f == null || f.getDtContr().compara(func.getDtContr()) > 0) {
                f = func;
            }
        }

        for (Gerente ger : gerentes) {
            if (f == null || f.getDtContr().compara(ger.getDtContr()) > 0) {
                f = ger;
            }
        }

        return f;
    }

    public Funcionario funcionarioMaisVelho() {
        Funcionario f = null;

        for (Funcionario func : funcionarios) {
            if (f == null || f.getDtNasc().compara(func.getDtNasc()) > 0) {
                f = func;
            }
        }

        for (Gerente ger : gerentes) {
            if (f == null || f.getDtNasc().compara(ger.getDtNasc()) > 0) {
                f = ger;
            }
        }

        return f;
    }

    public Funcionario localizarFuncionario(String cpf) {
        for (Funcionario f : funcionarios) {
            if (f.getCpf().equals(cpf)) {
                return f;
            }
        }

        return null;
    }

    public Gerente localizarGerente(String cpf) {
        for (Gerente g : gerentes) {
            if (g.getCpf().equals(cpf)) {
                return g;
            }
        }

        return null;
    }

    public void atribuirFuncGerente(Gerente g, Funcionario f) {
        if (g == null || f == null) {
            System.out.println("Erro: um dos cpfs é inválido.");
        }
        else {
            g.inserirFuncionarioEquipe(f);
        }
    }

}
