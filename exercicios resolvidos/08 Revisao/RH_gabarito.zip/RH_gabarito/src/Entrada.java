import java.util.Scanner;

public class Entrada {

    public static String lerLinha(String msg, Scanner input) {
        // Imprime uma mensagem ao usuario, le uma linha do teclado e retorna esta linha
        System.out.print(msg);
        String linha = input.nextLine();
        return linha;
    }

    public static int lerInteiro(String msg, Scanner input) {
        // Imprime uma mensagem ao usuario, le uma linha contendo um inteiro e retorna este inteiro
        String linha = Entrada.lerLinha(msg, input);
        return Integer.parseInt(linha);
    }

    private static double lerDouble(String msg, Scanner input) {
        // Imprime uma mensagem ao usuario, le uma linha contendo um double e retorna este double
        String linha = Entrada.lerLinha(msg, input);
        return Double.parseDouble(linha);
    }

    public static int menu(Scanner input) {
        // Imprime o menu principal, le a opcao escolhida pelo usuario e retorna a opcao selecionada.

        String msg = "*********************\n" +
                "Escolha uma opcao:\n" +
                "1) Contratar funcionário\n" +
                "2) Contratar gerente\n" +
                "3) Atribuir funcionario a gerente\n" +
                "4) Alterar senha de gerente\n" +
                "5) Funcionario mais antigo\n" +
                "6) Funcionario mais velho\n" +
                "7) Folha de pagamento mensal\n" +
                "0) Sair\n";

        int op = Entrada.lerInteiro(msg, input);

        while (op < 0 || op > 8) {
            System.out.println("Opcao invalida. Tente novamente: ");
            op = Entrada.lerInteiro(msg, input);
        }

        return op;
    }

    public static void contratarFuncionario(Empresa e, Scanner input) {
        String nome = Entrada.lerLinha("Digite o nome do funcionario: ", input);
        String cpf = Entrada.lerLinha("Digite o CPF do funcionario: ", input);
        double salario = Entrada.lerDouble("Digite o salario do funcionario: ", input);
        int dia1 = Entrada.lerInteiro("Digite o dia de nascimento do funcionário: ", input);
        int mes1 = Entrada.lerInteiro("Digite o mes de nascimento do funcionário: ", input);
        int ano1 = Entrada.lerInteiro("Digite o ano de nascimento do funcionário: ", input);
        int dia2 = Entrada.lerInteiro("Digite o dia de contratação do funcionário: ", input);
        int mes2 = Entrada.lerInteiro("Digite o mes de contratação do funcionário: ", input);
        int ano2 = Entrada.lerInteiro("Digite o ano de contratação do funcionário: ", input);

        e.inserirFuncionario(new Funcionario(nome, cpf, salario, new Data(dia1, mes1, ano1), new Data(dia2, mes2, ano2)));
    }

    public static void contratarGerente(Empresa e, Scanner input) {
        String nome = Entrada.lerLinha("Digite o nome do gerente: ", input);
        String cpf = Entrada.lerLinha("Digite o CPF do gerente: ", input);
        double salario = Entrada.lerDouble("Digite o salario do gerente: ", input);
        int dia1 = Entrada.lerInteiro("Digite o dia de nascimento do gerente: ", input);
        int mes1 = Entrada.lerInteiro("Digite o mes de nascimento do gerente: ", input);
        int ano1 = Entrada.lerInteiro("Digite o ano de nascimento do gerente: ", input);
        int dia2 = Entrada.lerInteiro("Digite o dia de contratação do gerente: ", input);
        int mes2 = Entrada.lerInteiro("Digite o mes de contratação do gerente: ", input);
        int ano2 = Entrada.lerInteiro("Digite o ano de contratação do gerente: ", input);
        String senha = Entrada.lerLinha("Digite a senha do gerente: ", input);

        e.inserirGerente(new Gerente(nome, cpf, salario, new Data(dia1, mes1, ano1), new Data(dia2, mes2, ano2), senha));
    }

    public static Funcionario selecionarFuncionario(Empresa e, Scanner input) {
        System.out.println("Funcionários cadastrados:");
        if (e.listarFuncionarios()) {
            String cpf = Entrada.lerLinha("Digite o CPF do funcionario: ", input);
            return e.localizarFuncionario(cpf);
        }
        else {
            return null;
        }
    }

    public static Gerente selecionarGerente(Empresa e, Scanner input) {
        System.out.println("Gerentes cadastrados:");
        if (e.listarGerentes()) {
            String cpf = Entrada.lerLinha("Digite o CPF do gerente: ", input);
            return e.localizarGerente(cpf);
        }
        else {
            return null;
        }
    }

    public static void atribuirFuncGerente(Empresa e, Scanner input) {
        Funcionario f = Entrada.selecionarFuncionario(e, input);
        Gerente g = Entrada.selecionarGerente(e, input);

        if (f != null && g != null) {
            e.atribuirFuncGerente(g, f);
        }
    }

    public static void alterarSenhaGerente(Empresa e, Scanner input) {
        Gerente g = Entrada.selecionarGerente(e, input);

        if (g != null) {
            String senhaAtual = Entrada.lerLinha("Digite a senha atual: ", input);
            String novaSenha = Entrada.lerLinha("Digite a nova senha: ", input);
            g.alterarSenha(senhaAtual, novaSenha);
        }
    }

    public static void funcionarioMaisAntigo(Empresa e, Scanner input) {
        Funcionario f = e.funcionarioMaisAntigo();

        if (f == null) {
            System.out.println("Erro: Funcionario não encontrado.");
        }
        else {
            f.listarDados();
        }
    }

    public static void funcionarioMaisVelho(Empresa e, Scanner input) {
        Funcionario f = e.funcionarioMaisVelho();

        if (f == null) {
            System.out.println("Erro: Funcionario não encontrado.");
        }
        else {
            f.listarDados();
        }
    }

}

