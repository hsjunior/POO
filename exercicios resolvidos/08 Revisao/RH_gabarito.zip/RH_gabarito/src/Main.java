import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
        Scanner input = new Scanner(System.in);
        Empresa e = new Empresa();

        int op = Entrada.menu(input);

        while (op != 0) {
            switch (op) {
                case 1:
                    Entrada.contratarFuncionario(e, input);
                    break;
                case 2:
                    Entrada.contratarGerente(e, input);
                    break;
                case 3:
                    Entrada.atribuirFuncGerente(e, input);
                    break;
                case 4:
                    Entrada.alterarSenhaGerente(e, input);
                    break;
                case 5:
                    Entrada.funcionarioMaisAntigo(e, input);
                    break;
                case 6:
                    Entrada.funcionarioMaisVelho(e, input);
                    break;
                case 7:
                    e.folhaPagamento();
            }
            op = Entrada.menu(input);
        }

        System.out.println("Bye!");
        input.close();
    }
}