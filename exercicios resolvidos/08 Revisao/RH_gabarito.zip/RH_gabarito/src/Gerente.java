import java.util.ArrayList;

public class Gerente extends Funcionario{
    private String senha;
    private ArrayList<Funcionario> equipe;

    public Gerente(String nome, String cpf, double salario, Data dtNasc, Data dtContr, String senha) {
        super(nome, cpf, salario, dtNasc, dtContr);
        this.senha = senha;

        this.equipe = new ArrayList<>();
    }

    public void listarDados() {
        System.out.print("GERENTE: ");
        super.listarDados();
    }

    public boolean validarAcesso(String senha) {
        return this.senha.equals(senha);
    }

    public void alterarSenha(String senhaAtual, String novaSenha) {
        if (this.validarAcesso(senhaAtual)) {
            this.senha = novaSenha;
            System.out.println("Senha alterada com sucesso!");
        }
        else {
            System.out.println("Senha atual incorreta!");
        }
    }

    public double custoEquipe() {
        double total = this.getSalario();
        for (Funcionario f : equipe) {
            total += f.getSalario();
        }
        return total;
    }

    public void listarEquipe() {
        this.listarDados();
        System.out.println("Funcionários da equipe:");
        for (Funcionario f : equipe) {
            f.listarDados();
        }
    }

    public void inserirFuncionarioEquipe(Funcionario f) {
        this.equipe.add(f);
    }

    public ArrayList<Funcionario> getEquipe() {
        return equipe;
    }

    public void setEquipe(ArrayList<Funcionario> equipe) {
        this.equipe = equipe;
    }
}
