public class Data {
    private int dia;
    private int mes;
    private int ano;

    public Data(int dia, int mes, int ano) {
        this.setDia(dia);
        this.setMes(mes);
        this.setAno(ano);
    }

    public int compara(Data d2) {
        if (this.getAno() > d2.getAno()) return 1;
        if (this.getAno() < d2.getAno()) return -1;

        if (this.getMes() > d2.getMes()) return 1;
        if (this.getMes() < d2.getMes()) return -1;

        if (this.getDia() > d2.getDia()) return 1;
        if (this.getDia() < d2.getDia()) return -1;

        return 0;
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
}
