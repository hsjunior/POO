public class Funcionario {
    protected String nome;
    protected String cpf;
    protected double salario;
    protected Data dtNasc;
    protected Data dtContr;

    public Funcionario(String nome, String cpf, double salario, Data dtNasc, Data dtContr) {
        this.setNome(nome);
        this.setCpf(cpf);
        this.setSalario(salario);
        this.setDtNasc(dtNasc);
        this.setDtContr(dtContr);
    }

    public void listarDados() {
        System.out.println(this.getNome() + " - CPF: " + this.getCpf() + " - R$ " + this.getSalario());
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public Data getDtNasc() {
        return dtNasc;
    }

    public void setDtNasc(Data dtNasc) {
        this.dtNasc = dtNasc;
    }

    public Data getDtContr() {
        return dtContr;
    }

    public void setDtContr(Data dtContr) {
        this.dtContr = dtContr;
    }
}
