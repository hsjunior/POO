import java.util.ArrayList;
import java.util.Locale;
import java.util.Scanner;

public class Entrada {

    /**
     * Faz a leitura de uma linha inteira
     * @param msg: Mensagem que será exibida ao usuário
     * @return Uma String contendo a linha que foi lida
     */
    public static String lerLinha(String msg, Scanner input) {
        // Imprime uma mensagem ao usuário, lê uma e retorna esta linha
        System.out.print(msg);
        String linha = input.nextLine();
        return linha;
    }

    /**
     * Faz a leitura de um número inteiro
     * @param msg: Mensagem que será exibida ao usuário
     * @return O número digitado pelo usuário convertido para int
     */
    public static int lerInteiro(String msg, Scanner input) {
        // Imprime uma mensagem ao usuário, lê uma linha contendo um inteiro e retorna este inteiro
        String linha = Entrada.lerLinha(msg, input);
        return Integer.parseInt(linha);
    }

    /**
     * Faz a leitura de um double
     * @param msg: Mensagem que será exibida ao usuário
     * @return O número digitado pelo usuário convertido para double
     */
    private static double lerDouble(String msg, Scanner input) {
        // Imprime uma mensagem ao usuário, lê uma linha contendo um double e retorna este double
        String linha = Entrada.lerLinha(msg, input);
        return Double.parseDouble(linha);
    }

    /**
     * Imprime o menu principal, lê a opção escolhida pelo usuário e retorna a opção selecionada.
     * @return Inteiro contendo a opção escolhida pelo usuário
     */
    public static int menu(Scanner input) {
        // Imprime o menu principal, lê a opção escolhida pelo usuário e retorna a opção selecionada.

        String msg = "*********************\n" +
                "Escolha uma opção:\n" +
                "1) Cadastro\n" +
                "2) Movimentações financeiras\n" +
                "0) Sair\n";

        int op = Entrada.lerInteiro(msg, input);

        while (op < 0 || op > 8) {
            System.out.println("Opção inválida. Tente novamente: ");
            op = Entrada.lerInteiro(msg, input);
        }

        return op;
    }

    public static void menu_cadastro(Sistema s, Scanner input) {
        String msg = "*********************\n" +
                "1) Adicionar pessoa\n" +
                "2) Adicionar gerente\n" +
                "3) Criar conta corrente\n" +
                "4) Criar poupança\n";

        int op = Entrada.lerInteiro(msg, input);

        switch(op) {
            case 1:
                Entrada.cadCliente(s, input);
                break;
            case 2:
                Entrada.cadGerente(s, input);
                break;
            case 3:
                Entrada.cadContaCorrente(s, input);
                break;
            case 4:
                Entrada.cadPoupanca(s, input);
                break;
            default:
                System.out.println("Opção Inválida.");
        }

    }

    public static void menu_movimentacoes(Sistema s, Scanner input) {
        String msg = "*********************\n" +
                "1) Verificar extrato\n" +
                "2) Depositar\n" +
                "3) Sacar\n" +
                "4) Transferir\n";

        int op = Entrada.lerInteiro(msg, input);

        switch(op) {
            case 1:
                Entrada.extrato(s, input);
                break;
            case 2:
                Entrada.depositar(s, input);
                break;
            case 3:
                Entrada.sacar(s, input);
                break;
            case 4:
                Entrada.transferir(s, input);
                break;
            default:
                System.out.println("Opção Inválida.");
        }

    }

    /**
     * Lê os dados de um novo Cliente e cadastra-o no sistema.
     * @param s: Um objeto da classe Sistema
     */
    public static void cadCliente(Sistema s, Scanner input) {
        String nome = Entrada.lerLinha("Digite o nome do cliente: ", input);
        String cpf = Entrada.lerLinha("Digite o cpf do cliente: ", input);
        int dia = Entrada.lerInteiro("Digite o dia do nascimento do cliente: ", input);
        int mes = Entrada.lerInteiro("Digite o mês do nascimento do cliente: ", input);
        int ano = Entrada.lerInteiro("Digite o ano do nascimento do cliente: ", input);
        char sexo = Entrada.lerLinha("Digite o sexo do cliente: ", input).charAt(0);

        s.cadastrarCliente(new Pessoa(nome, dia, mes, ano, sexo, cpf));
    }

    public static void cadGerente(Sistema s, Scanner input) {
        String nome = Entrada.lerLinha("Digite o nome do cliente: ", input);
        String cpf = Entrada.lerLinha("Digite o cpf do cliente: ", input);
        int dia = Entrada.lerInteiro("Digite o dia do nascimento do cliente: ", input);
        int mes = Entrada.lerInteiro("Digite o mês do nascimento do cliente: ", input);
        int ano = Entrada.lerInteiro("Digite o ano do nascimento do cliente: ", input);
        char sexo = Entrada.lerLinha("Digite o sexo do cliente: ", input).charAt(0);
        String mat = Entrada.lerLinha("Digite a matrícula do cliente: ", input);
        String senha = Entrada.lerLinha("Digite a senha do cliente: ", input);

        s.cadastrarGerente(new Gerente(nome, dia, mes, ano, sexo, cpf, mat, senha));
    }

    public static Pessoa escolherCliente(ArrayList<Pessoa> clientes, Scanner input) {
        System.out.println("Clientes cadastrados: ");
        int index = 0;
        for (Pessoa cliente : clientes) {
            System.out.println(index + ") " + cliente.getCpf() + " - " + cliente.getNome());
            index++;
        }
        index = Entrada.lerInteiro("Escolha o ciente pelo número: ", input);

        while (index < 0 || index >= clientes.size()) {
            System.out.println("Cliente inválido. Tente novamente: ");
            index = Entrada.lerInteiro("Escolha o ciente pelo número: ", input);
        }

        return clientes.get(index);
    }

    public static Gerente escolherGerente(ArrayList<Gerente> gerentes, Scanner input) {
        System.out.println("Gerentes cadastrados: ");
        int index = 0;
        for (Gerente g : gerentes) {
            System.out.println(index + ") " + g.getCpf() + " - " + g.getNome());
            index++;
        }
        index = Entrada.lerInteiro("Escolha o gerente pelo número: ", input);

        while (index < 0 || index >= gerentes.size()) {
            System.out.println("Gerente inválido. Tente novamente: ");
            index = Entrada.lerInteiro("Escolha o gerente pelo número: ", input);
        }

        return gerentes.get(index);
    }

    public static void cadContaCorrente(Sistema s, Scanner input) {
        ArrayList<Pessoa> clientes = s.getClientes();
        ArrayList<Gerente> gerentes = s.getGerentes();
        if (clientes.isEmpty() || gerentes.isEmpty()) {
            System.out.println("É preciso haver clientes e gerentes cadastrados no sistema para criar uma conta corrente.");
        }
        else {
            String numero = Entrada.lerLinha("Digite o número da conta corrente: ", input);
            Pessoa cliente = Entrada.escolherCliente(clientes, input);
            Gerente gerente = Entrada.escolherGerente(gerentes, input);
            int dia = Entrada.lerInteiro("Digite o dia de criacao da conta: ", input);
            int mes = Entrada.lerInteiro("Digite o mês de criacao da conta: ", input);
            int ano = Entrada.lerInteiro("Digite o ano de criacao da conta: ", input);
            double limite = Entrada.lerDouble("Digite o limite da conta: ", input);

            s.cadastrarConta(new ContaCorrente(numero, cliente, gerente, dia, mes, ano, limite));
        }
    }

    public static void cadPoupanca(Sistema s, Scanner input) {
        ArrayList<Pessoa> clientes = s.getClientes();
        ArrayList<Gerente> gerentes = s.getGerentes();
        if (clientes.isEmpty() || gerentes.isEmpty()) {
            System.out.println("É preciso haver clientes e gerentes cadastrados no sistema para criar uma poupanca.");
        }
        else {
            String numero = Entrada.lerLinha("Digite o número da poupanca: ", input);
            Pessoa cliente = Entrada.escolherCliente(clientes, input);
            Gerente gerente = Entrada.escolherGerente(gerentes, input);
            int dia = Entrada.lerInteiro("Digite o dia de criacao da poupanca: ", input);
            int mes = Entrada.lerInteiro("Digite o mês de criacao da poupanca: ", input);
            int ano = Entrada.lerInteiro("Digite o ano de criacao da poupanca: ", input);

            s.cadastrarConta(new Poupanca(numero, cliente, gerente, dia, mes, ano));
        }
    }

    public static Conta escolherConta(ArrayList<Conta> contas, Scanner input) {
        System.out.println("Contas cadastradas: ");
        int index = 0;
        for (Conta c : contas) {
            System.out.println(index + ") " + c.getNumero() + " (Titular: " + c.getTitular().getNome()  + ")");
            index++;
        }
        index = Entrada.lerInteiro("Escolha a conta pelo índice: ", input);

        while (index < 0 || index >= contas.size()) {
            System.out.println("Conta inválido. Tente novamente: ");
            index = Entrada.lerInteiro("Escolha a conta pelo índice: ", input);
        }

        return contas.get(index);
    }

    public static void extrato(Sistema s, Scanner input) {
        ArrayList<Conta> contas = s.getContas();

        if (contas.isEmpty()) {
            System.out.println("É preciso haver contas cadastradas no sistema para exibir um extrato.");
        }
        else {
            Conta c = Entrada.escolherConta(contas, input);
            c.extrato();
        }
    }

    public static void depositar(Sistema s, Scanner input) {
        ArrayList<Conta> contas = s.getContas();

        if (contas.isEmpty()) {
            System.out.println("É preciso haver contas cadastradas no sistema para fazer um deposito.");
        }
        else {
            Conta c = Entrada.escolherConta(contas, input);
            double valor = Entrada.lerDouble("Digite o valor a ser depositado: ", input);
            c.depositar(valor);
        }
    }

    public static void sacar(Sistema s, Scanner input) {
        ArrayList<Conta> contas = s.getContas();

        if (contas.isEmpty()) {
            System.out.println("É preciso haver contas cadastradas no sistema para fazer um saque.");
        }
        else {
            Conta c = Entrada.escolherConta(contas, input);
            double valor = Entrada.lerDouble("Digite o valor a ser sacado: ", input);
            c.sacar(valor);
        }
    }

    public static void transferir(Sistema s, Scanner input) {
        ArrayList<Conta> contas = s.getContas();

        if (contas.isEmpty()) {
            System.out.println("É preciso haver contas cadastradas no sistema para fazer uma transferencia.");
        }
        else {
            Conta c1 = Entrada.escolherConta(contas, input);
            Conta c2 = Entrada.escolherConta(contas, input);
            double valor = Entrada.lerDouble("Digite o valor a ser transferido: ", input);
            c1.transferir(valor, c2);
        }
    }



}
