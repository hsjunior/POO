import java.util.ArrayList;

public class Sistema {
    private ArrayList<Conta> contas = new ArrayList<>();
    private ArrayList<Gerente> gerentes = new ArrayList<>();
    private ArrayList<Pessoa> clientes = new ArrayList<>();

    public Sistema() {
        this.gerentes = new ArrayList<>();
        this.clientes = new ArrayList<>();
        this.contas = new ArrayList<>();
    }

    public void cadastrarConta(Conta conta) {
        this.contas.add(conta);
    }

    public void cadastrarGerente(Gerente gerente) {
        this.gerentes.add(gerente);
    }

    public void cadastrarCliente(Pessoa cliente) {
        this.clientes.add(cliente);
    }

    public ArrayList<Conta> getContas() {
        return contas;
    }

    public ArrayList<Gerente> getGerentes() {
        return gerentes;
    }

    public ArrayList<Pessoa> getClientes() {
        return clientes;
    }

}
