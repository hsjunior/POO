import java.util.Scanner;

public class Data {
    int dia;
    int mes;
    int ano;

    public Data(int dia, int mes, int ano) {
        this.setDia(dia);
        this.setMes(mes);
        this.setAno(ano);
    }

    public void imprimir() {
        System.out.println(this.getDia() + "/" + this.getMes() + "/" + this.getAno());
    }

    public boolean maior(Data data) {
        if (this.getAno() > data.getAno()) return true;
        if (this.getAno() < data.getAno()) return false;
        if (this.getMes() > data.getMes()) return true;
        if (this.getMes() < data.getMes()) return false;
        return this.getDia() > data.getDia();
    }

    public int getDia() {
        return dia;
    }

    public void setDia(int dia) {
        this.dia = dia;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }
}
