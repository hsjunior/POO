public class Conta {
    protected String numero;
    protected Pessoa titular;
    protected double saldo;
    protected Data criacao;
    protected Gerente ger;

    public Conta(String numero, Pessoa titular, Gerente ger, int dia, int mes, int ano) {
        this.setNumero(numero);
        this.setTitular(titular);
        this.setGer(ger);
        this.setCriacao(new Data(dia, mes, ano));
        this.setSaldo(0);
    }

    protected double disponivel() {
        return this.getSaldo();
    }

    public void depositar(double valor) {
        this.setSaldo(this.getSaldo() + valor);
    }

    public boolean sacar(double valor) {
        if (valor <= this.disponivel()) {
            this.setSaldo(this.getSaldo() - valor);
            System.out.println("Saque na conta " + this.getNumero() + " realizado com sucesso. Novo saldo: " + this.getSaldo());
            return true;
        }
        else {
            System.out.println("ERRO: Saque na conta " + this.getNumero() + " nao foi realizado. Valor disponivel: " + this.disponivel());
            return false;
        }
    }

    public boolean transferir(double valor, Conta destino) {
        if (this.sacar(valor)) {
            destino.depositar(valor);
            System.out.println("Transferencia de " + valor + " da conta " + this.getNumero() + " para a conta " + destino.getNumero() + " foi realizado com sucesso.");
            return true;
        }
        else {
            System.out.println("ERRO: Nao foi possivel transferir " + valor + " da conta " + this.getNumero() + " para a conta " + destino.getNumero() + ". Valor disponivel: " + this.disponivel());
            return false;
        }
    }

    public void extrato() {
        System.out.println("Conta: " + this.getNumero());
        System.out.println("Titular: " + this.getTitular().getCpf());
        System.out.println("Saldo disponivel para saque: " + this.disponivel());
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Pessoa getTitular() {
        return titular;
    }

    public void setTitular(Pessoa titular) {
        this.titular = titular;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public Data getCriacao() {
        return criacao;
    }

    public void setCriacao(Data criacao) {
        this.criacao = criacao;
    }

    public Gerente getGer() {
        return ger;
    }

    public void setGer(Gerente ger) {
        this.ger = ger;
    }
}
