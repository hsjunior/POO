public class Poupanca extends Conta{

    public Poupanca(String numero, Pessoa titular, Gerente ger, int dia, int mes, int ano) {
        super(numero, titular, ger, dia, mes, ano);
    }

    public void extrato() {
        System.out.println("*** EXTRATO DE POUPANCA ***");
        super.extrato();
    }

    public void rendimentos(double juro) {
        this.setSaldo(this.getSaldo() + (this.getSaldo() * juro / 100));
    }

}
