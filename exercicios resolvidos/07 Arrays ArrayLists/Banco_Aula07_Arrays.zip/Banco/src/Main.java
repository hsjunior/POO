import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Sistema banco = new Sistema();
        Scanner input = new Scanner(System.in);

        System.out.println("Bem vindo ao Banco!\n");

        int op = Entrada.menu(input);

        while (op != 0) {
            switch (op) {
                case 1:
                    Entrada.menu_cadastro(banco, input);
                    break;
                case 2:
                    Entrada.menu_movimentacoes(banco, input);
                    break;
                default:
                    System.out.println("Opção Inválida.");
            }
            op = Entrada.menu(input);
        }

        System.out.println("Bye!");
    }
}
