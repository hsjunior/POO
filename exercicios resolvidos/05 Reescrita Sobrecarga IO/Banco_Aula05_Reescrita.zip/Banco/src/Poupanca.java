public class Poupanca extends Conta{

    Poupanca(Gerente ger) {
        super(ger);
    }

    Poupanca(String numero, Pessoa titular, Gerente ger, int dia, int mes, int ano) {
        super(numero, titular, ger, dia, mes, ano);
    }

    void extrato() {
        System.out.println("*** EXTRATO DE POUPANCA ***");
        super.extrato();
    }

    void rendimentos(double juro) {
        this.saldo += (this.saldo * juro / 100);
    }

}
