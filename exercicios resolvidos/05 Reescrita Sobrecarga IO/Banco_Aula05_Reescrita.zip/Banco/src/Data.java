import java.util.Scanner;

public class Data {
    int dia, mes, ano;

    Data() {
        Scanner s = new Scanner(System.in);

        System.out.println("Digite o dia: ");
        this.dia = s.nextInt();

        System.out.println("Digite o mes: ");
        this.mes = s.nextInt();

        System.out.println("Digite o ano: ");
        this.ano = s.nextInt();
    }

    public Data(int dia, int mes, int ano) {
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }

    void imprimir() {
        System.out.println(this.dia + "/" + this.mes + "/" + this.ano);
    }

    boolean maior(Data data) {
        if (this.ano > data.ano) return true;
        if (this.ano < data.ano) return false;
        if (this.mes > data.mes) return true;
        if (this.mes < data.mes) return false;
        return this.dia > data.dia;
    }

}
