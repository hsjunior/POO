import java.util.Scanner;

public class Pessoa {
    String nome;
    Data dtNasc;
    char sexo;
    String cpf;

    Pessoa() {
        Scanner s = new Scanner(System.in);

        System.out.println("Digite o nome: ");
        this.nome = s.nextLine();

        System.out.println("Digite o cpf: ");
        this.nome = s.nextLine();

        System.out.println("Data de nascimento: ");
        this.dtNasc = new Data();

        System.out.println("Digite o sexo (M/F): ");
        this.sexo = s.next().charAt(0);
    }

    public Pessoa(String nome, int dia, int mes, int ano, char sexo, String cpf) {
        this.nome = nome;
        this.dtNasc = new Data(dia, mes, ano);
        this.sexo = sexo;
        this.cpf = cpf;
    }

    int idade(Data dataAtual) {
        int x = dataAtual.ano - this.dtNasc.ano;

        if (dataAtual.mes < this.dtNasc.mes) return x - 1;
        if (dataAtual.mes > this.dtNasc.mes) return x;

        if (dataAtual.dia < this.dtNasc.dia) return x - 1;
        return x;
    }
}
