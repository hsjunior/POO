import java.util.Scanner;

public class Gerente extends Pessoa {
    String matricula;
    String senha;

    Gerente() {
        super();

        Scanner s = new Scanner(System.in);

        System.out.println("Matricula: ");
        this.matricula = s.nextLine();

        System.out.println("Senha: ");
        this.senha = s.nextLine();
    }

    Gerente(String nome, int dia, int mes, int ano, char sexo, String cpf, String matricula, String senha) {
        super(nome, dia, mes, ano, sexo, cpf);
        this.matricula = matricula;
        this.senha = senha;
    }

    boolean validarAcesso(String senha) {
        return (this.senha.equals(senha));
    }

    boolean validarAcesso() {
        Scanner s = new Scanner(System.in);
        String senha = s.nextLine();
        return (this.validarAcesso(senha));
    }
}
