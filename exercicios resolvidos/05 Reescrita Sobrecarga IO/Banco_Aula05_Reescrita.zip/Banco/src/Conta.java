import java.util.Scanner;

public class Conta {
    String numero;
    Pessoa titular;
    double saldo;
    Data criacao;
    Gerente ger;

    Conta(Gerente ger) {
        Scanner s = new Scanner(System.in);

        System.out.println("Digite o numero da conta: ");
        this.numero = s.nextLine();

        System.out.println("Titular da conta:");
        this.titular = new Pessoa();

        System.out.println("Digite o saldo: ");
        this.saldo = s.nextDouble();

        System.out.println("Data de criacao: ");
        this.criacao = new Data();

        this.ger = ger;
    }

    public Conta(String numero, Pessoa titular, Gerente ger, int dia, int mes, int ano) {
        this.numero = numero;
        this.titular = titular;
        this.ger = ger;
        this.criacao = new Data(dia, mes, ano);
        this.saldo = 0;
    }

    double disponivel() {
        return this.saldo;
    }

    void depositar(double valor) {
        this.saldo += valor;
    }

    boolean sacar(double valor) {
        if (valor <= this.disponivel()) {
            this.saldo -= valor;
            System.out.println("Saque na conta " + this.numero + " realizado com sucesso. Novo saldo: " + this.saldo);
            return true;
        }
        else {
            System.out.println("ERRO: Saque na conta " + this.numero + " nao foi realizado. Valor disponivel: " + this.disponivel());
            return false;
        }
    }

    boolean transferir(double valor, Conta destino) {
        if (this.sacar(valor)) {
            destino.depositar(valor);
            System.out.println("Transferencia de " + valor + " da conta " + this.numero + " para a conta " + destino.numero + " foi realizado com sucesso.");
            return true;
        }
        else {
            System.out.println("ERRO: Nao foi possivel transferir " + valor + " da conta " + this.numero + " para a conta " + destino.numero + ". Valor disponivel: " + this.disponivel());
            return false;
        }
    }

    void extrato() {
        System.out.println("Conta: " + this.numero);
        System.out.println("Titular: " + this.titular.cpf);
        System.out.println("Saldo disponivel para saque: " + this.disponivel());
    }

}
