import java.util.Scanner;

public class ContaCorrente extends Conta {
    double limite;

    ContaCorrente(Gerente ger) {
        super(ger);
        Scanner s = new Scanner(System.in);
        this.limite = s.nextDouble();
    }

    ContaCorrente(String numero, Pessoa titular, Gerente ger, int dia, int mes, int ano, double limite) {
        super(numero, titular, ger, dia, mes, ano);
        this.limite = limite;
    }

    void alterarLimite(String senha, double limite) {
        if (this.ger.validarAcesso(senha)) {
            this.limite = limite;
            System.out.println("Senha alterada com sucesso.");
        }
        else {
            System.out.println("ERRO: Senha invalida.");
        }
    }

    void alterarLimite() {
        Scanner s = new Scanner(System.in);

        System.out.println("Digite a senha: ");
        String senha = s.nextLine();

        System.out.println("Digite o novo limite: ");
        double limite = s.nextDouble();

        this.alterarLimite(senha, limite);
    }

    double disponivel() {
        return this.saldo + this.limite;
    }

    void extrato() {
        System.out.println("*** EXTRATO DE CONTA CORRENTE ***");
        super.extrato();
    }

    void chequeEspecial(double juro) {
        if (this.saldo < 0) {
            this.saldo += (this.saldo * juro / 100);
        }
    }
}
