//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Pessoa p1 = new Pessoa("Maria", 21, 2, 2000, 'F', "123.456.789-00");
        Pessoa p2 = new Pessoa("Joao", 22, 10, 2001, 'M', "234.567.890-00");

        Gerente g = new Gerente("Pedro", 23, 8, 1999, 'M', "345.678.900-00", "123456", "abcdef");

        ContaCorrente c = new ContaCorrente("1234-5", p1, g, 10, 10, 2026, 1000);
        Poupanca p = new Poupanca("2345-6", p2, g, 8, 11, 2026);

        c.sacar(30);
        p.sacar(100);
        p.depositar(50);
        c.transferir(200, p);

        System.out.println(p.saldo);

    }
}