public class Conta {
    String numero;
    Pessoa titular;
    double saldo;
    Data criacao;
    Gerente ger;

    public Conta(String numero, Pessoa titular, Gerente ger, int dia, int mes, int ano) {
        this.numero = numero;
        this.titular = titular;
        this.ger = ger;
        this.criacao = new Data(dia, mes, ano);
        this.saldo = 0;
    }

    void depositar(double valor) {
        this.saldo += valor;
    }

}
