public class Data {
    int dia, mes, ano;

    public Data(int dia, int mes, int ano) {
        this.dia = dia;
        this.mes = mes;
        this.ano = ano;
    }

    void imprimir() {
        System.out.println(this.dia + "/" + this.mes + "/" + this.ano);
    }

    boolean maior(Data data) {
        if (this.ano > data.ano) return true;
        if (this.ano < data.ano) return false;
        if (this.mes > data.mes) return true;
        if (this.mes < data.mes) return false;
        return this.dia > data.dia;
    }

}
