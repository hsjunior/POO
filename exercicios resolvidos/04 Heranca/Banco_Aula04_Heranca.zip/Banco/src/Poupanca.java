public class Poupanca extends Conta{
    Poupanca(String numero, Pessoa titular, Gerente ger, int dia, int mes, int ano) {
        super(numero, titular, ger, dia, mes, ano);
    }

    double disponivel() {
        return this.saldo;
    }

    void extrato() {
        System.out.println("*** EXTRATO DE POUPANCA ***");
        System.out.println("Conta: " + this.numero);
        System.out.println("Titular: " + this.titular.cpf);
        System.out.println("Saldo disponivel para saque: " + this.disponivel());
    }

    boolean sacar(double valor) {
        if (valor <= this.disponivel()) {
            this.saldo -= valor;
            System.out.println("Saque na conta " + this.numero + " realizado com sucesso. Novo saldo: " + this.saldo);
            return true;
        }
        else {
            System.out.println("ERRO: Saque na conta " + this.numero + " nao foi realizado. Valor disponivel: " + this.disponivel());
            return false;
        }
    }

    boolean transferir(double valor, Conta destino) {
        if (this.sacar(valor)) {
            destino.depositar(valor);
            System.out.println("Transferencia de " + valor + " da conta " + this.numero + " para a conta " + destino.numero + " foi realizado com sucesso.");
            return true;
        }
        else {
            System.out.println("ERRO: Nao foi possivel transferir " + valor + " da conta " + this.numero + " para a conta " + destino.numero + ". Valor disponivel: " + this.disponivel());
            return false;
        }
    }

    void rendimentos(double juro) {
        this.saldo += (this.saldo * juro / 100);
    }

}
